const CustomerController = require ('../controller/customersController')
const express = require ('express')
const router = express.Router()

router.get('/getCustomer', CustomerController.getCustomer)


module.exports = router 