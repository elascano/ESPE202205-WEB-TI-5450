const Customer = require('../model/customers')


const getCustomer = (req, res) =>{
    Customer.find((err, Customer) =>{
        err && res.status(500).json(err.message)
        res.status(200).json(Customer)
    })
}


module.exports = {getCustomer}