const mongoose = require ('mongoose')
const Schema = mongoose.Schema

const CustomerSchema = Schema({
    id: {type: Number},
    name: {type: String},
    age: {type: Number},
    moneySpent: {type: Number}
},
    {collection: "Customer"}
)

module.exports = Customer = mongoose.model('Customer', CustomerSchema)