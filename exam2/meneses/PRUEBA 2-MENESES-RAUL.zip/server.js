const express = require('express')
const mongoose = require('mongoose')
const bodyParser = require('body-parser')
const portParemeter = 3000
const App= require('./app/app')

var app = express ()

app.use(bodyParser.urlencoded({extended: false}))
app.use(bodyParser.json())
app.use("/Customers", App)

mongoose.connect(
    "mongodb+srv://oop:oop@cluster0.9knxc.mongodb.net/computerstoredb?retryWrites=true&w=majority",
    {useNewUrlParser: true},
    (err, res) => {
        err && console.log("Error al conectarse a la base de datos")
        app.listen(portParemeter, ()=>{
            console.log(`Server is rouning on port ${portParemeter}`)
        })
    }
)